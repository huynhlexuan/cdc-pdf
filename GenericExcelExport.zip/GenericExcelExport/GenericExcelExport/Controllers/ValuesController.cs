﻿using GenericExcelExport.ExcelExport;
using GenericExcelExport.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GenericExcelExport.Controllers
{
    //[Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values/excelExport
        [HttpGet]
        public HttpResponseMessage ExcelExport()
        {
            //var ObjectToExcel = new List<DummyExternalLoginViewModel>
            //{
            //    new DummyExternalLoginViewModel { Name = "Mike", FamilyName= "Spencer", State = "TX"},
            //    new DummyExternalLoginViewModel { Name = "Donald", FamilyName= "Trump", State = "AL"},
            //    new DummyExternalLoginViewModel { Name = "Spencer", FamilyName= "Mike", State = "AK"},
            //    new DummyExternalLoginViewModel { Name = "Trump", FamilyName= "Donald", State = "AZ"},
            //    new DummyExternalLoginViewModel { Name = "Bill", FamilyName= "Gates", State = "AR"}
            //};
            var test = new List<ExternalLoginViewModel>
            {
                new ExternalLoginViewModel { Name = "Mike", FamilyName= "Spencer", State = "TX", Url ="google.com"},
                new ExternalLoginViewModel { Name = "Donald", FamilyName= "Trump", State = "AL", Url ="facebook.com"},
                new ExternalLoginViewModel { Name = "Spencer", FamilyName= "Mike", State = "AK", Url ="amazone.com"},
                new ExternalLoginViewModel { Name = "Trump", FamilyName= "Donald", State = "AZ", Url ="yahoo.com"},
            };

            //var resultContent = new AbstractDataExportBridge().Export(ObjectToExcel, "DummyExternalLoginViewModel");
            var testResult = new AbstractDataExportBridge().Export(test, "DummyExternalLoginViewModel",new List<string> { "FamilyName", "Url", "Name", "State" });

            return testResult;
        }
    }
}
