﻿using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;

namespace GenericExcelExport.ExcelExport
{

    public class AbstractDataExportBridge : AbstractDataExport
    {
        public AbstractDataExportBridge()
        {
            _headers = new List<string>();
            _type = new List<string>();
        }


        public override void WriteData<T>(List<T> exportData, List<string> customOrders)
        {
            //TO DO: Wrap Text

            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));

            var sortedProperties = properties.Cast<PropertyDescriptor>()
                                 .OrderBy(p => p.Name)
                                 .ToList();

            var propertyMap = sortedProperties.ToDictionary(prop => prop.Name, prop => prop);

            DataTable table = new DataTable();

            foreach (string columnName in customOrders)
            {
                if (propertyMap.ContainsKey(columnName))
                {
                    var prop = propertyMap[columnName];
                    var type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    _type.Add(type.Name);
                    table.Columns.Add(prop.Name, type);

                    // Generate the header from the property name
                    string name = Regex.Replace(prop.Name, "([A-Z])", " $1").Trim();
                    _headers.Add(name);
                }
            }

            foreach (T item in exportData)
            {
                DataRow row = table.NewRow();
                foreach (string columnName in customOrders)
                {
                    if (propertyMap.ContainsKey(columnName))
                    {
                        var prop = propertyMap[columnName];
                        row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                    }
                }
                table.Rows.Add(row);
            }

            IRow sheetRow = null;

            for (int i = 0; i < table.Rows.Count; i++)
            {
                sheetRow = _sheet.CreateRow(i + 1);
                for (int j = 0; j < table.Columns.Count; j++)
                {
                    //Below commented code is for Wrapping text, which is yet to be implemented, keep it there

                    //ICellStyle CellCentertTopAlignment = _workbook.CreateCellStyle();
                    //CellCentertTopAlignment = _workbook.CreateCellStyle();
                    //CellCentertTopAlignment.Alignment = HorizontalAlignment.Center;
                    ICell Row1 = sheetRow.CreateCell(j);
                    string cellvalue = Convert.ToString(table.Rows[i][j]);

                    // TODO: move it to switch case

                    //if (string.IsNullOrWhiteSpace(cellvalue))
                    //{
                    //    Row1.SetCellValue(string.Empty);
                    //}
                    //else if (_type[j].ToLower() == "string")
                    //{
                    //    Row1.SetCellValue(cellvalue);
                    //}
                    //else if (_type[j].ToLower() == "int32")
                    //{
                    //    Row1.SetCellValue(Convert.ToInt32(table.Rows[i][j]));
                    //}
                    //else if (_type[j].ToLower() == "double")
                    //{
                    //    Row1.SetCellValue(Convert.ToDouble(table.Rows[i][j]));
                    //}
                    //else if (_type[j].ToLower() == "datetime")
                    //{
                    //    Row1.SetCellValue(Convert.ToDateTime
                    //         (table.Rows[i][j]).ToString("dd/MM/yyyy hh:mm:ss"));
                    //}
                    //else
                    //{
                    //    Row1.SetCellValue(string.Empty);
                    //}

                    switch (_type[j].ToLower())
                    {
                        case "string":
                            Row1.SetCellValue(string.IsNullOrWhiteSpace(cellvalue) ? string.Empty : cellvalue);
                            break;

                        case "int32":
                            if (string.IsNullOrWhiteSpace(cellvalue))
                            {
                                Row1.SetCellValue(string.Empty);
                            }
                            else
                            {
                                Row1.SetCellValue(Convert.ToInt32(table.Rows[i][j]));
                            }
                            break;

                        case "double":
                            if (string.IsNullOrWhiteSpace(cellvalue))
                            {
                                Row1.SetCellValue(string.Empty);
                            }
                            else
                            {
                                Row1.SetCellValue(Convert.ToDouble(table.Rows[i][j]));
                            }
                            break;

                        case "datetime":
                            if (string.IsNullOrWhiteSpace(cellvalue))
                            {
                                Row1.SetCellValue(string.Empty);
                            }
                            else
                            {
                                Row1.SetCellValue(Convert.ToDateTime(table.Rows[i][j]).ToString("dd/MM/yyyy hh:mm:ss"));
                            }
                            break;

                        default:
                            Row1.SetCellValue(string.Empty);
                            break;
                    }

                    //Row1.CellStyle = CellCentertTopAlignment;
                    //Row1.CellStyle.WrapText = true;
                }
            }
        }
    }
}