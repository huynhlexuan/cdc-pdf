﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Aspose.Words;
using Aspose.Words.Markup;
using Aspose.Words.Tables;
using Microsoft.Extensions.Configuration;

namespace WordTemplateToPDF
{
    public interface ITemplateSerivce 
    {
        Stream ProduceDocumentFromTemplate(Stream templateStream, IReadOnlyDictionary<string, string> bookmarks, SaveFormat saveFormat = SaveFormat.Pdf);

    }

    public class TemplateService : ITemplateSerivce
    {
        public Stream ProduceDocumentFromTemplate(Stream templateStream, IReadOnlyDictionary<string, string> bookmarks,
               SaveFormat saveFormat = SaveFormat.Pdf)
        {
            var document = new Document(templateStream);

            UpdateContentControls(document, (IDictionary<string, string>)bookmarks);

            var outputStream = new MemoryStream();
            document.Save(outputStream, saveFormat);
            outputStream.Position = 0;

            return outputStream;
        }

        private void UpdateContentControls(Document document,
            IDictionary<string, string> bookmarkLookup)
        {
            var documentBookmarks = document.GetChildNodes(NodeType.StructuredDocumentTag, true)
                .OfType<StructuredDocumentTag>().ToDictionary(t => t.Tag, StringComparer.OrdinalIgnoreCase);

            foreach (var bookmarkPair in bookmarkLookup)
            {
                if (documentBookmarks.TryGetValue(bookmarkPair.Key, out var bookmark))
                {
                    if (bookmark.SdtType == SdtType.PlainText || bookmark.SdtType == SdtType.RichText)
                    {
                        UpdateTextContextControls(document, bookmark, bookmarkPair.Value);
                    }
                    else if (bookmark.SdtType is SdtType.Checkbox)
                    {
                        bookmark.Checked = bool.Parse(bookmarkPair.Value);
                    }
                    else if (bookmark.SdtType is SdtType.DropDownList)
                    {
                        bookmark.ListItems.SelectedValue = bookmark.ListItems
                            .First(item => string.Equals(item.Value, bookmarkPair.Value, StringComparison.OrdinalIgnoreCase));
                    }
                }
                else
                {
                    // bookmark is missing
                }
            }
        }

        private void UpdateTextContextControls(Document document, StructuredDocumentTag bookmark,string content)
        {
            if (bookmark.Level is MarkupLevel.Block)
            {
                HandleBookmarkLevelBlock(document, bookmark, content);
            }
            else if (bookmark.Level is MarkupLevel.Cell)
            {
                HandleBookmarkLevelCell(document, bookmark, content);
            }
            else
            {
                if (bookmark.FirstChild.NodeType == NodeType.Run)
                {
                    var run = (Run)bookmark.FirstChild.Clone(true);
                    run.Text = content;
                    bookmark.RemoveAllChildren();
                    bookmark.AppendChild(run);
                }
                else
                {
                    var run = new Run(document, content);
                    bookmark.RemoveAllChildren();
                    bookmark.AppendChild(run);
                }
            }
        }

        private void HandleBookmarkLevelBlock(Document document, StructuredDocumentTag bookmark, string context)
        {
            if (bookmark.FirstChild.NodeType == NodeType.Paragraph)
            {
                var paragraph = (Paragraph)bookmark.FirstChild.Clone(true);
                var run = (Run)paragraph.FirstChild.Clone(true);
                paragraph.RemoveAllChildren();
                run.Text = context;
                paragraph.AppendChild(run);

                bookmark.RemoveAllChildren();
                bookmark.AppendChild(paragraph);
            }
            else
            {
                var paragraph = new Paragraph(document);
                var run = new Run(document, context);
                paragraph.AppendChild(run);

                bookmark.RemoveAllChildren();
                bookmark.AppendChild(paragraph);
            }
        }

        private static void HandleBookmarkLevelCell(Document document, StructuredDocumentTag bookmark, string text)
        {
            if (bookmark.FirstChild.NodeType == NodeType.Cell)
            {
                var cell = (Cell)bookmark.FirstChild.Clone(true);
                var paragraph = (Paragraph)cell.FirstChild.Clone(true);
                var run = (Run)paragraph.FirstChild.Clone(true);
                paragraph.RemoveAllChildren();
                run.Text = text;
                paragraph.AppendChild(run);

                var cellCurrent = (Cell)bookmark.FirstChild;
                cellCurrent.RemoveAllChildren();
                cellCurrent.AppendChild(paragraph);
            }
            else
            {
                var paragraph = new Paragraph(document);
                var run = new Run(document, text);
                paragraph.AppendChild(run);

                var cell = (Cell)bookmark.FirstChild;
                cell.RemoveAllChildren();
                cell.AppendChild(paragraph);
            }
        }
    }
}
