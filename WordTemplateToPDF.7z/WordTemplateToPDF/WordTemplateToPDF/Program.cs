﻿using System;
using System.Collections.Generic;
using System.IO;

namespace WordTemplateToPDF
{
    class Program
    {
        static void Main(string[] args)
        {
            var replacements = PrepareReplacementsForTreatmentTemplate();
            var strFilePath = @"D:\Sample - iPlus Contract.dotx";
            var pdfPath = @"D:\Sample - iPlus Contract.pdf"; ;
            TemplateService templateService = new TemplateService();
            using FileStream templateStream = new FileStream(strFilePath, FileMode.Open);
            var stream = templateService.ProduceDocumentFromTemplate(templateStream, replacements);
            SaveFileStream(pdfPath, stream);
        }

        private static void SaveFileStream(string path, Stream stream)
        {
            var fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
            stream.CopyTo(fileStream);
            fileStream.Dispose();
        }

        // will get data and convert to dictionary
        private static Dictionary<string, string> PrepareReplacementsForTreatmentTemplate()
            => new Dictionary<string, string>
            {
                {"ContractDate", "2024-08-27" },
                {"Condo", "Verysell Coporation"},
                {"Date", "2024-08-27"},
                {"CompanyB", "Verysell Coporation"},
                {"CompanyA", "Fermax Coporation"},
            };
    }
}
